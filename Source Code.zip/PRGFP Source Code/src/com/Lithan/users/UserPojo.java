package com.Lithan.users;

public class UserPojo {

	private String ufname;
	private String ulname;
	private String Uname;
	private String uemail;
	private String pword;
	private String unum;
	private String ubasequali;
	private String country;	

	
	public String getUfname()
	{
		return ufname;
	}

	public void setUfname(String ufname)
	{
		
		this.ufname = ufname;
		
	}

	public String getUlname()
	{
		return ulname;
	}

	public void setUlname(String ulname)
	{
		this.ulname = ulname;
	}

	public String getUname()
	{
		return Uname;
	}

	public void setUname(String Uname)
	{
		this.Uname = Uname;
	}
	
	public String getUemail()
	{
		return uemail;
	}

	public void setUemail(String uemail)
	{
		this.uemail = uemail;
	}

	public String getPword()
	{
		return pword;
	}

	public void setPword(String pword)
	{
		this.pword = pword;
	}

	public String getUnum() {
		return unum;
	}

	public void setUnum(String unum) {
		this.unum = unum;
	}

	public String getUbasequali() {
		return ubasequali;
	}

	public void setUbasequali(String ubasequali) {
		this.ubasequali = ubasequali;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}
}
